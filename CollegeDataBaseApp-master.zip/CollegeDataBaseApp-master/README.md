# CollegeDataBaseApp
It is an app which enables student-teacher communication as well as student-student communication in an improved manner.
It enables the students to share documents,chat and discuss, give quiz tests, submit assignments and make video blogs. 
The teacher is the admin of the group and he/she has to login through the admin portal to set up the quizes and assignments.
It is uses firebase realtime database and storage for data and file transfer.
